<?php


namespace Zijinghua\Zvoyager\Http\Requests;


use Zijinghua\Zbasement\Http\Requests\BaseRequest;

class LoginRequest extends BaseRequest
{
    protected $bread_action='login';
}