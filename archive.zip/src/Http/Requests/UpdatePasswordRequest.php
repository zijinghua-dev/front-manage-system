<?php


namespace App\Http\Requests;


use Zijinghua\Zbasement\Http\Requests\BaseRequest;

class UpdatePasswordRequest extends BaseRequest
{
    protected $bread_action='updatePassword';
}