<?php


namespace Zijinghua\Zvoyager\Http\Contracts;


interface UserServiceInterface
{

}